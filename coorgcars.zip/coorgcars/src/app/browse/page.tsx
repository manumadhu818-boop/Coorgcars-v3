import { Suspense } from "react";
import { getCarListings } from "@/lib/actions/cars";
import CarGrid from "@/components/cars/CarGrid";
import SearchFilters from "@/components/cars/SearchFilters";
import Footer from "@/components/layout/Footer";
import { SearchFilters as IFilters, FuelType, TransmissionType, BodyType } from "@/types";

export const metadata = { title: "Browse Cars — CoorgCars" };

interface BrowsePageProps {
  searchParams: Promise<Record<string, string>>;
}

export default async function BrowsePage({ searchParams }: BrowsePageProps) {
  const params = await searchParams;

  const filters: IFilters = {
    brand: params.brand || "",
    fuel_type: (params.fuel_type as FuelType) || "",
    city: params.city || "",
    min_price: params.min_price ? parseInt(params.min_price) : undefined,
    max_price: params.max_price ? parseInt(params.max_price) : undefined,
    transmission: (params.transmission as TransmissionType) || "",
    body_type: (params.body_type as BodyType) || "",
    sort_by: (params.sort_by as IFilters["sort_by"]) || "newest",
  };

  const { data: cars } = await getCarListings(filters);

  const activeFilters = Object.entries(filters)
    .filter(([k, v]) => v && k !== "sort_by")
    .map(([k, v]) => `${k}: ${v}`);

  return (
    <>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Browse Cars</h1>
          <p className="text-dark-400 text-sm">
            {cars.length} car{cars.length !== 1 ? "s" : ""} found
            {activeFilters.length > 0 ? " matching your filters" : ""}
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8">
          <Suspense fallback={<div className="card p-5 h-20 animate-pulse" />}>
            <SearchFilters />
          </Suspense>
        </div>

        {/* Active filter chips */}
        {activeFilters.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {params.brand && (
              <span className="badge bg-brand-500/10 text-brand-400 border border-brand-500/20 text-xs px-3 py-1">
                Brand: {params.brand}
              </span>
            )}
            {params.fuel_type && (
              <span className="badge bg-brand-500/10 text-brand-400 border border-brand-500/20 text-xs px-3 py-1">
                Fuel: {params.fuel_type}
              </span>
            )}
            {params.city && (
              <span className="badge bg-brand-500/10 text-brand-400 border border-brand-500/20 text-xs px-3 py-1">
                City: {params.city}
              </span>
            )}
            {params.body_type && (
              <span className="badge bg-brand-500/10 text-brand-400 border border-brand-500/20 text-xs px-3 py-1">
                Type: {params.body_type}
              </span>
            )}
          </div>
        )}

        {/* Grid */}
        <CarGrid cars={cars} />
      </div>

      <Footer />
    </>
  );
}
