import { redirect } from "next/navigation";
import Link from "next/link";
import { Plus, Car, Eye, TrendingUp, LayoutDashboard } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getDealerListings } from "@/lib/actions/cars";
import StatsCard from "@/components/dashboard/StatsCard";
import ListingRow from "@/components/dashboard/ListingRow";
import { CarListing } from "@/types";

export const metadata = { title: "Dashboard — CoorgCars" };

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/auth/login");

  const { data: dealer } = await supabase
    .from("dealers")
    .select("*")
    .eq("id", user.id)
    .single();

  if (!dealer) redirect("/auth/register");

  const listings: CarListing[] = await getDealerListings(user.id);

  const activeListings = listings.filter((l) => l.is_active && !l.is_sold);
  const totalViews = listings.reduce((sum, l) => sum + (l.views || 0), 0);
  const soldListings = listings.filter((l) => l.is_sold);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <LayoutDashboard className="w-5 h-5 text-brand-500" />
            <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          </div>
          <p className="text-dark-400 text-sm">
            Welcome back, <span className="text-dark-200">{dealer.name}</span> —{" "}
            {dealer.business_name}
          </p>
        </div>
        <Link href="/dashboard/listings/new" className="btn-primary">
          <Plus className="w-4 h-4" />
          Add New Listing
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
        <StatsCard
          label="Total Listings"
          value={listings.length}
          icon={Car}
          color="orange"
        />
        <StatsCard
          label="Active Listings"
          value={activeListings.length}
          icon={TrendingUp}
          color="green"
        />
        <StatsCard
          label="Total Views"
          value={totalViews.toLocaleString()}
          icon={Eye}
          color="blue"
        />
        <StatsCard
          label="Cars Sold"
          value={soldListings.length}
          icon={Car}
          color="purple"
        />
      </div>

      {/* Listings */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-white">My Listings</h2>
          {listings.length > 0 && (
            <span className="text-sm text-dark-400">{listings.length} total</span>
          )}
        </div>

        {listings.length === 0 ? (
          <div className="card p-16 text-center">
            <div className="w-16 h-16 bg-dark-700 rounded-2xl flex items-center justify-center mx-auto mb-5">
              <Car className="w-7 h-7 text-dark-400" />
            </div>
            <h3 className="text-lg font-semibold text-dark-100 mb-2">No listings yet</h3>
            <p className="text-dark-400 text-sm mb-6">
              Add your first car listing to start reaching buyers.
            </p>
            <Link href="/dashboard/listings/new" className="btn-primary inline-flex">
              <Plus className="w-4 h-4" />
              Add Your First Car
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {listings.map((listing) => (
              <ListingRow key={listing.id} listing={listing} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
