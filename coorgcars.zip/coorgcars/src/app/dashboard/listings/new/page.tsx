import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import AddListingForm from "@/components/cars/AddListingForm";

export const metadata = { title: "Add Listing — CoorgCars" };

export default async function NewListingPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/auth/login");

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link href="/dashboard" className="btn-ghost p-2">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-white">Add New Listing</h1>
          <p className="text-dark-400 text-sm mt-0.5">Fill in the details to publish your car</p>
        </div>
      </div>

      <AddListingForm dealerId={user.id} />
    </div>
  );
}
