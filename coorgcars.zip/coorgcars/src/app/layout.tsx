import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "react-hot-toast";
import Navbar from "@/components/layout/Navbar";

export const metadata: Metadata = {
  title: "CoorgCars — Premium Used Cars in Coorg & Beyond",
  description:
    "Find certified pre-owned cars from trusted dealers across Coorg, Mysore, Bangalore and India. Best prices, verified listings.",
  keywords:
    "used cars, pre-owned cars, Coorg cars, buy used car, sell car, certified cars",
  openGraph: {
    title: "CoorgCars — Premium Used Cars",
    description: "Find certified pre-owned cars from trusted dealers",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-dark-950 text-dark-50 antialiased">
        <Navbar />
        <main>{children}</main>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: "#161b22",
              color: "#e6edf3",
              border: "1px solid #30363d",
              borderRadius: "12px",
            },
            success: {
              iconTheme: { primary: "#f97316", secondary: "#080a0e" },
            },
          }}
        />
      </body>
    </html>
  );
}
