import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import {
  MapPin, Calendar, Gauge, Fuel, GitBranch, Users, Palette,
  Car, Phone, CheckCircle, ArrowLeft, Eye, Share2,
} from "lucide-react";
import { getCarById } from "@/lib/actions/cars";
import { formatPrice, formatKm, getOwnershipLabel } from "@/lib/utils";
import WhatsAppButton from "@/components/cars/WhatsAppButton";
import Footer from "@/components/layout/Footer";
import { CarListingWithDealer } from "@/types";
import ImageGallery from "@/components/cars/ImageGallery";

interface CarDetailPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: CarDetailPageProps) {
  const { id } = await params;
  const car = await getCarById(id) as CarListingWithDealer | null;
  if (!car) return { title: "Car Not Found — CoorgCars" };
  return {
    title: `${car.title} — CoorgCars`,
    description: `${car.year} ${car.brand} ${car.model} | ${formatKm(car.km_driven)} | ${formatPrice(car.price)} | ${car.city}`,
  };
}

export default async function CarDetailPage({ params }: CarDetailPageProps) {
  const { id } = await params;
  const car = await getCarById(id) as CarListingWithDealer | null;

  if (!car) notFound();

  const dealer = car.dealers;

  const specs = [
    { icon: Calendar, label: "Year", value: car.year },
    { icon: Gauge, label: "KM Driven", value: formatKm(car.km_driven) },
    { icon: Fuel, label: "Fuel Type", value: car.fuel_type },
    { icon: GitBranch, label: "Transmission", value: car.transmission },
    { icon: Users, label: "Ownership", value: getOwnershipLabel(car.ownership) },
    { icon: Car, label: "Body Type", value: car.body_type || "N/A" },
    { icon: Palette, label: "Color", value: car.color || "N/A" },
    { icon: MapPin, label: "Location", value: `${car.location}, ${car.city}` },
  ];

  return (
    <>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-dark-400 mb-6 pt-4">
          <Link href="/" className="hover:text-dark-200 transition-colors">Home</Link>
          <span>/</span>
          <Link href="/browse" className="hover:text-dark-200 transition-colors">Browse</Link>
          <span>/</span>
          <span className="text-dark-200 truncate max-w-[200px]">{car.title}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Images + Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Gallery */}
            <ImageGallery images={car.images} title={car.title} />

            {/* Title & Price */}
            <div className="card p-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-white mb-1">{car.title}</h1>
                  <div className="flex items-center gap-2 text-sm text-dark-300">
                    <MapPin className="w-3.5 h-3.5 text-brand-500" />
                    {car.location}, {car.city}
                    <span className="text-dark-600">•</span>
                    <Eye className="w-3.5 h-3.5" />
                    {car.views} views
                  </div>
                </div>
                <button className="btn-ghost p-2 rounded-xl">
                  <Share2 className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-end gap-3 mb-4">
                <p className="text-4xl font-extrabold text-white">{formatPrice(car.price)}</p>
                {car.is_negotiable && (
                  <span className="badge bg-green-500/10 text-green-400 border border-green-500/20 mb-1">
                    Negotiable
                  </span>
                )}
              </div>

              {/* Quick spec pills */}
              <div className="flex flex-wrap gap-2">
                {[
                  `${car.year}`,
                  `${formatKm(car.km_driven)}`,
                  car.fuel_type,
                  car.transmission,
                  getOwnershipLabel(car.ownership),
                ].map((s) => (
                  <span key={s} className="badge bg-dark-700 text-dark-200 border border-dark-600 text-xs px-3 py-1.5">
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* Specs Grid */}
            <div className="card p-6">
              <h2 className="font-semibold text-white mb-5">Car Specifications</h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {specs.map(({ icon: Icon, label, value }) => (
                  <div key={label} className="bg-dark-700 rounded-xl p-4 text-center">
                    <Icon className="w-5 h-5 text-brand-500 mx-auto mb-2" />
                    <p className="text-xs text-dark-400 mb-1">{label}</p>
                    <p className="text-sm font-semibold text-dark-50">{String(value)}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Description */}
            {car.description && (
              <div className="card p-6">
                <h2 className="font-semibold text-white mb-4">Description</h2>
                <p className="text-dark-300 text-sm leading-relaxed whitespace-pre-line">
                  {car.description}
                </p>
              </div>
            )}
          </div>

          {/* Right: Dealer Card (sticky) */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-4">
              {/* Dealer Card */}
              <div className="card p-6">
                <h3 className="font-semibold text-white mb-4">Dealer Info</h3>

                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 bg-brand-500/20 rounded-xl flex items-center justify-center text-brand-400 font-bold text-lg">
                    {dealer?.business_name?.[0]?.toUpperCase() || "D"}
                  </div>
                  <div>
                    <p className="font-semibold text-dark-50">{dealer?.business_name}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      {dealer?.is_verified && (
                        <>
                          <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                          <span className="text-xs text-green-400">Verified Dealer</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mb-5 text-sm">
                  <div className="flex items-center gap-2.5 text-dark-300">
                    <MapPin className="w-4 h-4 text-brand-500 shrink-0" />
                    {dealer?.location}, {dealer?.city}
                  </div>
                  <div className="flex items-center gap-2.5 text-dark-300">
                    <Phone className="w-4 h-4 text-brand-500 shrink-0" />
                    {dealer?.phone}
                  </div>
                </div>

                <div className="space-y-3">
                  {dealer?.whatsapp && (
                    <WhatsAppButton
                      phone={dealer.whatsapp}
                      carTitle={car.title}
                      carId={car.id}
                      className="w-full"
                      size="md"
                    />
                  )}
                  <a
                    href={`tel:${dealer?.phone}`}
                    className="btn-secondary w-full py-3 text-sm"
                  >
                    <Phone className="w-4 h-4" />
                    Call Dealer
                  </a>
                </div>
              </div>

              {/* Safety note */}
              <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4">
                <p className="text-amber-400 text-xs font-medium mb-1">Safety Tip</p>
                <p className="text-dark-400 text-xs leading-relaxed">
                  Always inspect the vehicle in person and verify all documents before making payment.
                </p>
              </div>

              {/* Back button */}
              <Link href="/browse" className="btn-ghost w-full justify-center text-sm">
                <ArrowLeft className="w-4 h-4" />
                Back to Browse
              </Link>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
