import Link from "next/link";
import { Car, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center">
        <div className="w-20 h-20 bg-dark-800 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Car className="w-9 h-9 text-dark-400" />
        </div>
        <h1 className="text-6xl font-extrabold text-white mb-3">404</h1>
        <p className="text-dark-300 text-lg mb-2">Page not found</p>
        <p className="text-dark-500 text-sm mb-8 max-w-sm mx-auto">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>
        <div className="flex gap-3 justify-center">
          <Link href="/" className="btn-primary">
            <ArrowLeft className="w-4 h-4" />
            Go Home
          </Link>
          <Link href="/browse" className="btn-secondary">
            Browse Cars
          </Link>
        </div>
      </div>
    </div>
  );
}
