import Link from "next/link";
import { ArrowRight, Shield, Zap, Search, Star, Car, TrendingUp } from "lucide-react";
import { getCarListings } from "@/lib/actions/cars";
import CarCard from "@/components/cars/CarCard";
import Footer from "@/components/layout/Footer";

const BRANDS = [
  { name: "Maruti", emoji: "🚗" },
  { name: "Hyundai", emoji: "🚙" },
  { name: "Tata", emoji: "🚘" },
  { name: "Mahindra", emoji: "🛻" },
  { name: "Toyota", emoji: "🚐" },
  { name: "Honda", emoji: "🏎️" },
  { name: "Kia", emoji: "🚗" },
  { name: "BMW", emoji: "🏁" },
];

export default async function HomePage() {
  const { data: featuredCars } = await getCarListings({ sort_by: "newest" });
  const latest = featuredCars.slice(0, 6);

  return (
    <>
      {/* ── Hero ── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-hero-pattern" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-dark-950/50 to-dark-950" />

        {/* Decorative glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-brand-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 text-center">
          {/* Eyebrow */}
          <div className="inline-flex items-center gap-2 bg-brand-500/10 border border-brand-500/20 text-brand-400 text-xs font-medium px-4 py-2 rounded-full mb-8">
            <Star className="w-3.5 h-3.5" />
            Trusted by 500+ Dealers Across India
          </div>

          <h1 className="text-5xl sm:text-6xl md:text-7xl font-extrabold text-white leading-[1.05] tracking-tight mb-6">
            Find Your{" "}
            <span className="text-gradient">Perfect</span>
            <br />
            Pre-Owned Car
          </h1>

          <p className="text-dark-300 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Certified used cars from verified dealers in Coorg, Bangalore, Mysore
            and across India. Real prices. Zero hassle.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link href="/browse" className="btn-primary text-base py-4 px-8">
              Browse All Cars
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/auth/register" className="btn-secondary text-base py-4 px-8">
              List Your Car
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto">
            {[
              { label: "Cars Listed", value: "1,200+" },
              { label: "Cities", value: "25+" },
              { label: "Dealers", value: "500+" },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <p className="text-2xl font-bold text-white">{s.value}</p>
                <p className="text-xs text-dark-400 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quick Search Bar ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-10">
        <div className="bg-dark-800 border border-dark-600 rounded-2xl p-5 shadow-2xl">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
              <input
                type="text"
                placeholder="Search by brand, model, city..."
                className="input-field pl-11 w-full"
                readOnly
                onClick={() => window.location.href = "/browse"}
              />
            </div>
            <Link href="/browse" className="btn-primary whitespace-nowrap">
              Search Cars
            </Link>
          </div>
        </div>
      </section>

      {/* ── Browse by Brand ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex items-center justify-between mb-8">
          <h2 className="section-title">Browse by Brand</h2>
          <Link href="/browse" className="text-brand-400 hover:text-brand-300 text-sm font-medium flex items-center gap-1 transition-colors">
            See all <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
          {BRANDS.map((brand) => (
            <Link
              key={brand.name}
              href={`/browse?brand=${brand.name}`}
              className="flex flex-col items-center gap-2 p-3 bg-dark-800 hover:bg-dark-700 border border-dark-600 hover:border-brand-500/40 rounded-xl transition-all group"
            >
              <span className="text-2xl">{brand.emoji}</span>
              <span className="text-xs text-dark-300 group-hover:text-dark-100 font-medium transition-colors text-center leading-tight">
                {brand.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* ── Featured Listings ── */}
      {latest.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="section-title">Latest Listings</h2>
              <p className="text-dark-400 text-sm mt-1">Fresh cars added by verified dealers</p>
            </div>
            <Link href="/browse" className="text-brand-400 hover:text-brand-300 text-sm font-medium flex items-center gap-1 transition-colors">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {latest.map((car) => (
              <CarCard key={car.id} car={car} />
            ))}
          </div>

          <div className="text-center mt-10">
            <Link href="/browse" className="btn-secondary">
              Explore All Cars
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </section>
      )}

      {/* ── Why CoorgCars ── */}
      <section className="border-t border-dark-700 bg-dark-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-14">
            <h2 className="section-title mb-3">Why CoorgCars?</h2>
            <p className="text-dark-400 max-w-xl mx-auto text-sm">
              We&apos;ve built the most dealer-friendly and buyer-trusted platform for
              pre-owned cars in the region.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              {
                icon: Shield,
                title: "Verified Dealers",
                desc: "Every dealer is reviewed and verified before going live. No scams, no fake listings.",
                color: "text-brand-400 bg-brand-500/10",
              },
              {
                icon: Zap,
                title: "List in Minutes",
                desc: "Upload photos, fill in details and your car is live within minutes. No waiting.",
                color: "text-blue-400 bg-blue-500/10",
              },
              {
                icon: TrendingUp,
                title: "Maximum Reach",
                desc: "Buyers across Coorg, Bangalore, Mysore and all of India browse your listings daily.",
                color: "text-green-400 bg-green-500/10",
              },
            ].map((f) => (
              <div key={f.title} className="card p-7">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 ${f.color}`}>
                  <f.icon className="w-6 h-6" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{f.title}</h3>
                <p className="text-dark-400 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="relative bg-gradient-to-br from-brand-600/20 to-brand-800/10 border border-brand-500/20 rounded-3xl p-10 md:p-16 text-center overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-brand-500/5 rounded-full blur-3xl" />
          <Car className="w-12 h-12 text-brand-500 mx-auto mb-5" />
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to sell your car?
          </h2>
          <p className="text-dark-300 mb-8 max-w-lg mx-auto">
            Join 500+ dealers already using CoorgCars. Register free and post your first listing today.
          </p>
          <Link href="/auth/register" className="btn-primary text-base py-4 px-10">
            Start Selling Free
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      <Footer />
    </>
  );
}
