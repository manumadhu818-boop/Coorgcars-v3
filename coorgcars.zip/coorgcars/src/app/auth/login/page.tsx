import { Car } from "lucide-react";
import Link from "next/link";
import LoginForm from "@/components/auth/LoginForm";

export const metadata = { title: "Sign In — CoorgCars" };

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-24">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2.5 mb-6">
            <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center">
              <Car className="w-5 h-5 text-white" />
            </div>
            <span className="text-white font-bold text-xl">
              Coorg<span className="text-brand-500">Cars</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold text-white mb-1">Welcome back</h1>
          <p className="text-dark-400 text-sm">Sign in to your dealer account</p>
        </div>

        <div className="card p-8">
          <LoginForm />
        </div>
      </div>
    </div>
  );
}
