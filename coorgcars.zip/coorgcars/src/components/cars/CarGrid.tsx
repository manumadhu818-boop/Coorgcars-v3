import { CarListing } from "@/types";
import CarCard from "./CarCard";
import { Car } from "lucide-react";

interface CarGridProps {
  cars: CarListing[];
  loading?: boolean;
}

function SkeletonCard() {
  return (
    <div className="card overflow-hidden">
      <div className="skeleton aspect-[16/10]" />
      <div className="p-4 space-y-3">
        <div className="skeleton h-7 w-1/2 rounded-lg" />
        <div className="skeleton h-4 w-3/4 rounded-lg" />
        <div className="grid grid-cols-3 gap-2">
          <div className="skeleton h-12 rounded-lg" />
          <div className="skeleton h-12 rounded-lg" />
          <div className="skeleton h-12 rounded-lg" />
        </div>
        <div className="skeleton h-4 w-1/3 rounded-lg" />
      </div>
    </div>
  );
}

export default function CarGrid({ cars, loading }: CarGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {Array.from({ length: 6 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  if (!cars.length) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-20 h-20 bg-dark-800 rounded-2xl flex items-center justify-center mb-5">
          <Car className="w-9 h-9 text-dark-400" />
        </div>
        <h3 className="text-xl font-semibold text-dark-100 mb-2">No cars found</h3>
        <p className="text-dark-400 text-sm max-w-xs">
          Try adjusting your search filters or check back later for new listings.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {cars.map((car) => (
        <CarCard key={car.id} car={car} />
      ))}
    </div>
  );
}
