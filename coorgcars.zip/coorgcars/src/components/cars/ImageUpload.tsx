"use client";

import { useState, useRef, useCallback } from "react";
import Image from "next/image";
import { Upload, X, Image as ImageIcon, Loader2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import toast from "react-hot-toast";

interface ImageUploadProps {
  value: string[];
  onChange: (urls: string[]) => void;
  maxImages?: number;
  dealerId: string;
}

export default function ImageUpload({
  value,
  onChange,
  maxImages = 4,
  dealerId,
}: ImageUploadProps) {
  const [uploading, setUploading] = useState<number[]>([]);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const supabase = createClient();

  const uploadFile = async (file: File, index: number) => {
    const ext = file.name.split(".").pop();
    const fileName = `${dealerId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;

    const { error } = await supabase.storage
      .from("car-images")
      .upload(fileName, file, { cacheControl: "3600", upsert: false });

    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage
      .from("car-images")
      .getPublicUrl(fileName);

    return publicUrl;
  };

  const handleFiles = async (files: File[]) => {
    const remaining = maxImages - value.length;
    const toUpload = files.slice(0, remaining);

    if (!toUpload.length) {
      toast.error(`Maximum ${maxImages} images allowed`);
      return;
    }

    const indices = toUpload.map((_, i) => value.length + i);
    setUploading(indices);

    try {
      const urls = await Promise.all(
        toUpload.map((file, i) => uploadFile(file, indices[i]))
      );
      onChange([...value, ...urls]);
      toast.success(`${urls.length} image${urls.length > 1 ? "s" : ""} uploaded`);
    } catch {
      toast.error("Upload failed. Please try again.");
    } finally {
      setUploading([]);
    }
  };

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      const files = Array.from(e.dataTransfer.files).filter((f) =>
        f.type.startsWith("image/")
      );
      handleFiles(files);
    },
    [value]
  );

  const removeImage = (index: number) => {
    onChange(value.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-3">
      {/* Upload zone */}
      {value.length < maxImages && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200 ${
            dragging
              ? "border-brand-500 bg-brand-500/10"
              : "border-dark-500 hover:border-brand-500/50 hover:bg-dark-700/50"
          }`}
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files) {
                handleFiles(Array.from(e.target.files));
                e.target.value = "";
              }
            }}
          />
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-12 bg-dark-700 rounded-xl flex items-center justify-center">
              <Upload className="w-5 h-5 text-brand-500" />
            </div>
            <div>
              <p className="text-dark-100 font-medium text-sm">
                {dragging ? "Drop images here" : "Click or drag images to upload"}
              </p>
              <p className="text-dark-400 text-xs mt-1">
                JPG, PNG, WEBP — up to {maxImages} images ({value.length}/{maxImages} used)
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Image previews */}
      {(value.length > 0 || uploading.length > 0) && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {value.map((url, i) => (
            <div key={url} className="relative aspect-square bg-dark-700 rounded-xl overflow-hidden group">
              <Image src={url} alt={`Car image ${i + 1}`} fill className="object-cover" />
              {i === 0 && (
                <div className="absolute bottom-1.5 left-1.5 bg-brand-500 text-white text-xs px-1.5 py-0.5 rounded-md font-medium">
                  Cover
                </div>
              )}
              <button
                type="button"
                onClick={() => removeImage(i)}
                className="absolute top-1.5 right-1.5 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="w-3 h-3 text-white" />
              </button>
            </div>
          ))}

          {uploading.map((i) => (
            <div key={`uploading-${i}`} className="aspect-square bg-dark-700 rounded-xl flex items-center justify-center">
              <Loader2 className="w-5 h-5 text-brand-500 animate-spin" />
            </div>
          ))}

          {/* Empty slots */}
          {Array.from({ length: maxImages - value.length - uploading.length }).map((_, i) => (
            <div
              key={`empty-${i}`}
              onClick={() => inputRef.current?.click()}
              className="aspect-square bg-dark-800 border border-dashed border-dark-600 rounded-xl flex items-center justify-center cursor-pointer hover:border-dark-400 transition-colors"
            >
              <ImageIcon className="w-5 h-5 text-dark-500" />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
