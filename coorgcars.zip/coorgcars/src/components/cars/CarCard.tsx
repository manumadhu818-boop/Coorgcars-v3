import Link from "next/link";
import Image from "next/image";
import { MapPin, Fuel, Gauge, Calendar, GitBranch, CheckCircle } from "lucide-react";
import { CarListing } from "@/types";
import { formatPrice, formatKm, getOwnershipLabel } from "@/lib/utils";

const FUEL_COLORS: Record<string, string> = {
  Petrol: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  Diesel: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  Electric: "bg-green-500/10 text-green-400 border-green-500/20",
  Hybrid: "bg-teal-500/10 text-teal-400 border-teal-500/20",
  CNG: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  LPG: "bg-pink-500/10 text-pink-400 border-pink-500/20",
};

export default function CarCard({ car }: { car: CarListing }) {
  const mainImage = car.images?.[0];

  return (
    <Link href={`/cars/${car.id}`} className="group block">
      <div className="card-hover h-full flex flex-col">
        {/* Image */}
        <div className="relative aspect-[16/10] bg-dark-700 overflow-hidden">
          {mainImage ? (
            <Image
              src={mainImage}
              alt={car.title}
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-500"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-dark-700">
              <span className="text-dark-400 text-sm">No Image</span>
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-3 left-3 flex gap-2">
            <span className={`badge border ${FUEL_COLORS[car.fuel_type] || "bg-dark-600 text-dark-200 border-dark-500"}`}>
              {car.fuel_type}
            </span>
          </div>

          {car.is_negotiable && (
            <div className="absolute top-3 right-3">
              <span className="badge bg-brand-500/20 text-brand-400 border border-brand-500/30">
                Negotiable
              </span>
            </div>
          )}

          {/* Image count */}
          {car.images?.length > 1 && (
            <div className="absolute bottom-3 right-3 bg-black/60 text-white text-xs px-2 py-1 rounded-lg backdrop-blur-sm">
              {car.images.length} photos
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4 flex flex-col flex-1">
          {/* Price */}
          <div className="flex items-start justify-between mb-2">
            <p className="text-2xl font-bold text-white">
              {formatPrice(car.price)}
            </p>
            <span className="text-xs text-dark-300 mt-1.5">{getOwnershipLabel(car.ownership)}</span>
          </div>

          {/* Title */}
          <h3 className="font-semibold text-dark-50 text-sm leading-snug mb-3 line-clamp-1 group-hover:text-brand-400 transition-colors">
            {car.title}
          </h3>

          {/* Specs row */}
          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="flex flex-col items-center bg-dark-700 rounded-lg py-2 px-1">
              <Calendar className="w-3.5 h-3.5 text-dark-300 mb-1" />
              <span className="text-xs font-medium text-dark-100">{car.year}</span>
            </div>
            <div className="flex flex-col items-center bg-dark-700 rounded-lg py-2 px-1">
              <Gauge className="w-3.5 h-3.5 text-dark-300 mb-1" />
              <span className="text-xs font-medium text-dark-100">{formatKm(car.km_driven)}</span>
            </div>
            <div className="flex flex-col items-center bg-dark-700 rounded-lg py-2 px-1">
              <GitBranch className="w-3.5 h-3.5 text-dark-300 mb-1" />
              <span className="text-xs font-medium text-dark-100">{car.transmission}</span>
            </div>
          </div>

          {/* Location */}
          <div className="flex items-center gap-1.5 mt-auto">
            <MapPin className="w-3.5 h-3.5 text-brand-500 shrink-0" />
            <span className="text-xs text-dark-300 truncate">{car.city}</span>
            {(car as CarListing & { dealers?: { is_verified: boolean } }).dealers?.is_verified && (
              <div className="ml-auto flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                <span className="text-xs text-green-400">Verified</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
