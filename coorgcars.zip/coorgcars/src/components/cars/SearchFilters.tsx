"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState, useEffect } from "react";
import { Search, SlidersHorizontal, X, ChevronDown } from "lucide-react";
import { CAR_BRANDS, FUEL_TYPES, TRANSMISSION_TYPES, BODY_TYPES, INDIAN_CITIES } from "@/types";

export default function SearchFilters() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [filters, setFilters] = useState({
    brand: searchParams.get("brand") || "",
    fuel_type: searchParams.get("fuel_type") || "",
    city: searchParams.get("city") || "",
    min_price: searchParams.get("min_price") || "",
    max_price: searchParams.get("max_price") || "",
    transmission: searchParams.get("transmission") || "",
    body_type: searchParams.get("body_type") || "",
    sort_by: searchParams.get("sort_by") || "newest",
  });

  const applyFilters = () => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => {
      if (v) params.set(k, v);
    });
    router.push(`/browse?${params.toString()}`);
  };

  const clearFilters = () => {
    setFilters({
      brand: "", fuel_type: "", city: "", min_price: "",
      max_price: "", transmission: "", body_type: "", sort_by: "newest",
    });
    router.push("/browse");
  };

  const hasActiveFilters = Object.entries(filters).some(
    ([k, v]) => v && k !== "sort_by"
  );

  const set = (key: string, value: string) =>
    setFilters((prev) => ({ ...prev, [key]: value }));

  return (
    <div className="bg-dark-800 border border-dark-600 rounded-2xl p-5">
      {/* Primary row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Brand */}
        <div className="relative">
          <select
            value={filters.brand}
            onChange={(e) => set("brand", e.target.value)}
            className="select-field pr-10"
          >
            <option value="">All Brands</option>
            {CAR_BRANDS.map((b) => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
        </div>

        {/* Fuel */}
        <div className="relative">
          <select
            value={filters.fuel_type}
            onChange={(e) => set("fuel_type", e.target.value)}
            className="select-field pr-10"
          >
            <option value="">All Fuel Types</option>
            {FUEL_TYPES.map((f) => (
              <option key={f} value={f}>{f}</option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
        </div>

        {/* City */}
        <div className="relative">
          <select
            value={filters.city}
            onChange={(e) => set("city", e.target.value)}
            className="select-field pr-10"
          >
            <option value="">All Cities</option>
            {INDIAN_CITIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
        </div>

        {/* Sort */}
        <div className="relative">
          <select
            value={filters.sort_by}
            onChange={(e) => set("sort_by", e.target.value)}
            className="select-field pr-10"
          >
            <option value="newest">Newest First</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="km_asc">Lowest KM</option>
            <option value="oldest">Oldest First</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
        </div>
      </div>

      {/* Advanced filters */}
      {showAdvanced && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-3 pt-3 border-t border-dark-600">
          <input
            type="number"
            placeholder="Min Price (₹)"
            value={filters.min_price}
            onChange={(e) => set("min_price", e.target.value)}
            className="input-field"
          />
          <input
            type="number"
            placeholder="Max Price (₹)"
            value={filters.max_price}
            onChange={(e) => set("max_price", e.target.value)}
            className="input-field"
          />
          <div className="relative">
            <select
              value={filters.transmission}
              onChange={(e) => set("transmission", e.target.value)}
              className="select-field pr-10"
            >
              <option value="">All Transmissions</option>
              {TRANSMISSION_TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={filters.body_type}
              onChange={(e) => set("body_type", e.target.value)}
              className="select-field pr-10"
            >
              <option value="">All Body Types</option>
              {BODY_TYPES.map((b) => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
          </div>
        </div>
      )}

      {/* Action row */}
      <div className="flex items-center gap-3 mt-4">
        <button onClick={applyFilters} className="btn-primary py-2.5 px-5 text-sm flex-1 sm:flex-none">
          <Search className="w-4 h-4" />
          Search
        </button>
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="btn-secondary py-2.5 px-4 text-sm"
        >
          <SlidersHorizontal className="w-4 h-4" />
          {showAdvanced ? "Less" : "More Filters"}
        </button>
        {hasActiveFilters && (
          <button onClick={clearFilters} className="btn-ghost text-sm text-red-400 hover:text-red-300">
            <X className="w-4 h-4" />
            Clear
          </button>
        )}
      </div>
    </div>
  );
}
