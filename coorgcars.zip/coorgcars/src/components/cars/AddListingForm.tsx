"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { ChevronDown, Loader2, Save } from "lucide-react";
import { createCarListing } from "@/lib/actions/cars";
import ImageUpload from "@/components/cars/ImageUpload";
import {
  CAR_BRANDS, FUEL_TYPES, TRANSMISSION_TYPES, BODY_TYPES,
  INDIAN_CITIES, CarListingFormData, FuelType, TransmissionType, BodyType,
} from "@/types";

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 25 }, (_, i) => CURRENT_YEAR - i);

export default function AddListingForm({ dealerId }: { dealerId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState<string[]>([]);

  const [form, setForm] = useState<CarListingFormData>({
    title: "",
    brand: "",
    model: "",
    variant: "",
    year: CURRENT_YEAR,
    fuel_type: "Petrol",
    transmission: "Manual",
    body_type: "",
    color: "",
    km_driven: 0,
    ownership: 1,
    city: "",
    location: "",
    price: 0,
    is_negotiable: true,
    description: "",
  });

  const set = (key: keyof CarListingFormData, value: unknown) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  // Auto-generate title
  const autoTitle = () => {
    if (form.brand && form.model && form.year) {
      set("title", `${form.year} ${form.brand} ${form.model}${form.variant ? " " + form.variant : ""}`);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.brand || !form.model || !form.price || !form.city) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (images.length === 0) {
      toast.error("Please upload at least one image");
      return;
    }

    setLoading(true);
    try {
      const result = await createCarListing(form, images);
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success("Listing created successfully!");
        router.push("/dashboard");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Images */}
      <section className="card p-6">
        <h2 className="text-lg font-semibold text-white mb-1">Photos</h2>
        <p className="text-dark-300 text-sm mb-5">Upload up to 4 photos. First image will be the cover.</p>
        <ImageUpload value={images} onChange={setImages} dealerId={dealerId} maxImages={4} />
      </section>

      {/* Basic Info */}
      <section className="card p-6 space-y-5">
        <h2 className="text-lg font-semibold text-white">Car Details</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Brand */}
          <div className="form-group">
            <label className="label">Brand <span className="text-red-400">*</span></label>
            <div className="relative">
              <select value={form.brand} onChange={(e) => { set("brand", e.target.value); setTimeout(autoTitle, 0); }} className="select-field pr-10" required>
                <option value="">Select Brand</option>
                {CAR_BRANDS.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
            </div>
          </div>

          {/* Model */}
          <div className="form-group">
            <label className="label">Model <span className="text-red-400">*</span></label>
            <input
              type="text" value={form.model} placeholder="e.g. Swift, Creta, Nexon"
              onChange={(e) => { set("model", e.target.value); setTimeout(autoTitle, 0); }}
              className="input-field" required
            />
          </div>

          {/* Variant */}
          <div className="form-group">
            <label className="label">Variant</label>
            <input
              type="text" value={form.variant} placeholder="e.g. VXi, SX(O)"
              onChange={(e) => { set("variant", e.target.value); setTimeout(autoTitle, 0); }}
              className="input-field"
            />
          </div>

          {/* Year */}
          <div className="form-group">
            <label className="label">Year <span className="text-red-400">*</span></label>
            <div className="relative">
              <select value={form.year} onChange={(e) => { set("year", parseInt(e.target.value)); setTimeout(autoTitle, 0); }} className="select-field pr-10" required>
                {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
            </div>
          </div>

          {/* Fuel */}
          <div className="form-group">
            <label className="label">Fuel Type <span className="text-red-400">*</span></label>
            <div className="relative">
              <select value={form.fuel_type} onChange={(e) => set("fuel_type", e.target.value as FuelType)} className="select-field pr-10" required>
                {FUEL_TYPES.map((f) => <option key={f} value={f}>{f}</option>)}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
            </div>
          </div>

          {/* Transmission */}
          <div className="form-group">
            <label className="label">Transmission <span className="text-red-400">*</span></label>
            <div className="relative">
              <select value={form.transmission} onChange={(e) => set("transmission", e.target.value as TransmissionType)} className="select-field pr-10" required>
                {TRANSMISSION_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
            </div>
          </div>

          {/* Body Type */}
          <div className="form-group">
            <label className="label">Body Type</label>
            <div className="relative">
              <select value={form.body_type} onChange={(e) => set("body_type", e.target.value as BodyType | "")} className="select-field pr-10">
                <option value="">Select Body Type</option>
                {BODY_TYPES.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
            </div>
          </div>

          {/* Color */}
          <div className="form-group">
            <label className="label">Color</label>
            <input type="text" value={form.color} placeholder="e.g. Polar White" onChange={(e) => set("color", e.target.value)} className="input-field" />
          </div>

          {/* KM Driven */}
          <div className="form-group">
            <label className="label">KM Driven <span className="text-red-400">*</span></label>
            <input type="number" value={form.km_driven || ""} placeholder="e.g. 45000" onChange={(e) => set("km_driven", parseInt(e.target.value) || 0)} className="input-field" required min={0} />
          </div>

          {/* Ownership */}
          <div className="form-group">
            <label className="label">Ownership <span className="text-red-400">*</span></label>
            <div className="relative">
              <select value={form.ownership} onChange={(e) => set("ownership", parseInt(e.target.value))} className="select-field pr-10" required>
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>{n === 5 ? "5th+ Owner" : `${n}${["st","nd","rd","th","th"][n-1]} Owner`}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="form-group">
          <label className="label">Listing Title <span className="text-red-400">*</span></label>
          <input type="text" value={form.title} placeholder="Auto-generated or enter custom title" onChange={(e) => set("title", e.target.value)} className="input-field" required />
          <p className="text-xs text-dark-400 mt-1">A good title increases visibility. Auto-filled when you enter brand, model & year.</p>
        </div>
      </section>

      {/* Location & Pricing */}
      <section className="card p-6 space-y-5">
        <h2 className="text-lg font-semibold text-white">Location & Price</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="form-group">
            <label className="label">City <span className="text-red-400">*</span></label>
            <div className="relative">
              <select value={form.city} onChange={(e) => set("city", e.target.value)} className="select-field pr-10" required>
                <option value="">Select City</option>
                {INDIAN_CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
            </div>
          </div>

          <div className="form-group">
            <label className="label">Location / Area <span className="text-red-400">*</span></label>
            <input type="text" value={form.location} placeholder="e.g. Madikeri, Virajpet" onChange={(e) => set("location", e.target.value)} className="input-field" required />
          </div>

          <div className="form-group">
            <label className="label">Price (₹) <span className="text-red-400">*</span></label>
            <input type="number" value={form.price || ""} placeholder="e.g. 550000" onChange={(e) => set("price", parseInt(e.target.value) || 0)} className="input-field" required min={1} />
          </div>

          <div className="form-group">
            <label className="label">Negotiable?</label>
            <div className="flex gap-3 mt-1">
              {[true, false].map((val) => (
                <button
                  key={String(val)}
                  type="button"
                  onClick={() => set("is_negotiable", val)}
                  className={`flex-1 py-3 rounded-xl border text-sm font-medium transition-all ${
                    form.is_negotiable === val
                      ? "bg-brand-500 border-brand-500 text-white"
                      : "bg-dark-800 border-dark-500 text-dark-200 hover:border-dark-400"
                  }`}
                >
                  {val ? "Yes" : "No"}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Description */}
      <section className="card p-6 space-y-3">
        <h2 className="text-lg font-semibold text-white">Description</h2>
        <textarea
          value={form.description}
          onChange={(e) => set("description", e.target.value)}
          placeholder="Describe the condition, service history, features, reason for selling..."
          rows={5}
          className="input-field resize-none"
        />
      </section>

      {/* Submit */}
      <div className="flex gap-4">
        <button type="submit" disabled={loading} className="btn-primary flex-1 sm:flex-none py-3.5">
          {loading ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> Publishing...</>
          ) : (
            <><Save className="w-4 h-4" /> Publish Listing</>
          )}
        </button>
        <button type="button" onClick={() => router.back()} className="btn-secondary py-3.5">
          Cancel
        </button>
      </div>
    </form>
  );
}
