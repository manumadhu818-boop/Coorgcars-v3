"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { Menu, X, Car, ChevronDown, LogOut, LayoutDashboard, Plus } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import type { User } from "@supabase/supabase-js";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: listener } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "glass border-b border-dark-600 shadow-xl"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center group-hover:bg-brand-600 transition-colors">
              <Car className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-white font-bold text-lg leading-none">Coorg</span>
              <span className="text-brand-500 font-bold text-lg leading-none">Cars</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            <Link href="/browse" className="btn-ghost text-sm">
              Browse Cars
            </Link>
            <Link href="/browse?fuel_type=Electric" className="btn-ghost text-sm">
              Electric
            </Link>
          </div>

          {/* Desktop Auth */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-dark-700 hover:bg-dark-600 border border-dark-500 text-sm font-medium transition-all"
                >
                  <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center text-white text-xs font-bold">
                    {user.email?.[0].toUpperCase()}
                  </div>
                  <span className="text-dark-100">My Account</span>
                  <ChevronDown className={`w-4 h-4 text-dark-300 transition-transform ${isDropdownOpen ? "rotate-180" : ""}`} />
                </button>

                {isDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-52 bg-dark-800 border border-dark-600 rounded-xl shadow-2xl overflow-hidden">
                    <Link
                      href="/dashboard"
                      onClick={() => setIsDropdownOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-dark-700 text-sm text-dark-100 transition-colors"
                    >
                      <LayoutDashboard className="w-4 h-4 text-brand-500" />
                      Dashboard
                    </Link>
                    <Link
                      href="/dashboard/listings/new"
                      onClick={() => setIsDropdownOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-dark-700 text-sm text-dark-100 transition-colors"
                    >
                      <Plus className="w-4 h-4 text-brand-500" />
                      Add Listing
                    </Link>
                    <div className="border-t border-dark-600" />
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-dark-700 text-sm text-red-400 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link href="/auth/login" className="btn-ghost text-sm">
                  Sign In
                </Link>
                <Link href="/auth/register" className="btn-primary text-sm py-2.5 px-5">
                  List Your Car
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-xl text-dark-200 hover:text-white hover:bg-dark-700"
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden glass border-t border-dark-600">
          <div className="px-4 py-4 space-y-1">
            <Link
              href="/browse"
              onClick={() => setIsMenuOpen(false)}
              className="block px-4 py-3 rounded-xl text-dark-100 hover:bg-dark-700 text-sm"
            >
              Browse Cars
            </Link>
            <Link
              href="/browse?fuel_type=Electric"
              onClick={() => setIsMenuOpen(false)}
              className="block px-4 py-3 rounded-xl text-dark-100 hover:bg-dark-700 text-sm"
            >
              Electric Cars
            </Link>
            <div className="border-t border-dark-600 my-2" />
            {user ? (
              <>
                <Link
                  href="/dashboard"
                  onClick={() => setIsMenuOpen(false)}
                  className="block px-4 py-3 rounded-xl text-dark-100 hover:bg-dark-700 text-sm"
                >
                  Dashboard
                </Link>
                <Link
                  href="/dashboard/listings/new"
                  onClick={() => setIsMenuOpen(false)}
                  className="block px-4 py-3 rounded-xl text-dark-100 hover:bg-dark-700 text-sm"
                >
                  Add Listing
                </Link>
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-3 rounded-xl text-red-400 hover:bg-dark-700 text-sm"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link
                  href="/auth/login"
                  onClick={() => setIsMenuOpen(false)}
                  className="block px-4 py-3 rounded-xl text-dark-100 hover:bg-dark-700 text-sm"
                >
                  Sign In
                </Link>
                <Link
                  href="/auth/register"
                  onClick={() => setIsMenuOpen(false)}
                  className="block btn-primary text-sm text-center"
                >
                  List Your Car
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
