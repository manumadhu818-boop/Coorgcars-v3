import Link from "next/link";
import { Car, Phone, Mail, MapPin, Instagram, Twitter, Facebook } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-dark-900 border-t border-dark-600 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center">
                <Car className="w-5 h-5 text-white" />
              </div>
              <span className="text-white font-bold text-lg">
                Coorg<span className="text-brand-500">Cars</span>
              </span>
            </Link>
            <p className="text-dark-300 text-sm leading-relaxed">
              Premium pre-owned cars from verified dealers across Coorg, Mysore,
              Bangalore and all of India.
            </p>
            <div className="flex gap-3 mt-5">
              {[Instagram, Twitter, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 bg-dark-700 hover:bg-dark-600 rounded-lg flex items-center justify-center text-dark-300 hover:text-white transition-all"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Browse</h4>
            <ul className="space-y-2.5">
              {[
                { label: "All Cars", href: "/browse" },
                { label: "Electric Cars", href: "/browse?fuel_type=Electric" },
                { label: "Diesel Cars", href: "/browse?fuel_type=Diesel" },
                { label: "SUVs", href: "/browse?body_type=SUV" },
                { label: "Sedans", href: "/browse?body_type=Sedan" },
              ].map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-dark-300 hover:text-brand-400 text-sm transition-colors"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Dealers */}
          <div>
            <h4 className="text-white font-semibold mb-4">Dealers</h4>
            <ul className="space-y-2.5">
              {[
                { label: "Register as Dealer", href: "/auth/register" },
                { label: "Dealer Login", href: "/auth/login" },
                { label: "Add Listing", href: "/dashboard/listings/new" },
                { label: "My Dashboard", href: "/dashboard" },
              ].map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-dark-300 hover:text-brand-400 text-sm transition-colors"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2.5 text-dark-300 text-sm">
                <MapPin className="w-4 h-4 text-brand-500 shrink-0" />
                Madikeri, Coorg, Karnataka
              </li>
              <li className="flex items-center gap-2.5 text-dark-300 text-sm">
                <Phone className="w-4 h-4 text-brand-500 shrink-0" />
                +91 98765 43210
              </li>
              <li className="flex items-center gap-2.5 text-dark-300 text-sm">
                <Mail className="w-4 h-4 text-brand-500 shrink-0" />
                hello@coorgcars.in
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-dark-600 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-dark-400 text-sm">
            © {new Date().getFullYear()} CoorgCars. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-dark-400 hover:text-dark-200 text-sm transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-dark-400 hover:text-dark-200 text-sm transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
