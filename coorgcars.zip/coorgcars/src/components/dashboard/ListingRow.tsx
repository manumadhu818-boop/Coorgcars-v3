"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Eye, EyeOff, Trash2, ExternalLink, Loader2 } from "lucide-react";
import { CarListing } from "@/types";
import { formatPrice, formatKm } from "@/lib/utils";
import { deleteCarListing, toggleListingStatus } from "@/lib/actions/cars";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";

export default function ListingRow({ listing }: { listing: CarListing }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleToggle = async () => {
    setLoading(true);
    const result = await toggleListingStatus(listing.id, !listing.is_active);
    if (result.error) toast.error(result.error);
    else {
      toast.success(listing.is_active ? "Listing paused" : "Listing activated");
      router.refresh();
    }
    setLoading(false);
  };

  const handleDelete = async () => {
    if (!confirm(`Delete "${listing.title}"? This cannot be undone.`)) return;
    setLoading(true);
    const result = await deleteCarListing(listing.id);
    if (result.error) toast.error(result.error);
    else { toast.success("Listing deleted"); router.refresh(); }
    setLoading(false);
  };

  const image = listing.images?.[0];

  return (
    <div className="card p-4 flex flex-col sm:flex-row gap-4">
      {/* Thumbnail */}
      <div className="relative w-full sm:w-28 h-28 sm:h-20 bg-dark-700 rounded-xl overflow-hidden shrink-0">
        {image ? (
          <Image src={image} alt={listing.title} fill className="object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-dark-500 text-xs">No image</div>
        )}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-semibold text-dark-50 text-sm truncate">{listing.title}</h3>
          <span className={`badge shrink-0 ${listing.is_active ? "bg-green-500/10 text-green-400" : "bg-dark-600 text-dark-300"}`}>
            {listing.is_active ? "Active" : "Paused"}
          </span>
        </div>

        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-dark-300 mb-3">
          <span className="font-semibold text-white text-sm">{formatPrice(listing.price)}</span>
          <span>{listing.year} · {listing.fuel_type}</span>
          <span>{formatKm(listing.km_driven)}</span>
          <span>{listing.city}</span>
          <span className="flex items-center gap-1">
            <Eye className="w-3 h-3" /> {listing.views} views
          </span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Link
            href={`/cars/${listing.id}`}
            className="btn-ghost text-xs py-1.5 px-3 gap-1.5"
            target="_blank"
          >
            <ExternalLink className="w-3.5 h-3.5" /> View
          </Link>

          <button
            onClick={handleToggle}
            disabled={loading}
            className="btn-ghost text-xs py-1.5 px-3 gap-1.5"
          >
            {loading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : listing.is_active ? (
              <><EyeOff className="w-3.5 h-3.5" /> Pause</>
            ) : (
              <><Eye className="w-3.5 h-3.5" /> Activate</>
            )}
          </button>

          <button
            onClick={handleDelete}
            disabled={loading}
            className="btn-ghost text-xs py-1.5 px-3 gap-1.5 text-red-400 hover:text-red-300 hover:bg-red-500/10"
          >
            <Trash2 className="w-3.5 h-3.5" /> Delete
          </button>
        </div>
      </div>
    </div>
  );
}
