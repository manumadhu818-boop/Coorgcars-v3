"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Eye, EyeOff, Loader2, ChevronDown } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import toast from "react-hot-toast";
import { INDIAN_CITIES } from "@/types";

export default function RegisterForm() {
  const router = useRouter();
  const supabase = createClient();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    name: "",
    business_name: "",
    phone: "",
    whatsapp: "",
    location: "",
    city: "",
    email: "",
    password: "",
  });

  const set = (key: string, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }

    setLoading(true);
    try {
      // Sign up
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
      });

      if (authError) { toast.error(authError.message); return; }
      if (!authData.user) { toast.error("Registration failed"); return; }

      // Create dealer profile
      const { error: dealerError } = await supabase.from("dealers").insert({
        id: authData.user.id,
        name: form.name,
        business_name: form.business_name,
        phone: form.phone,
        whatsapp: form.whatsapp || form.phone,
        location: form.location,
        city: form.city,
        email: form.email,
      });

      if (dealerError) { toast.error(dealerError.message); return; }

      toast.success("Account created! Welcome to CoorgCars.");
      router.push("/dashboard");
      router.refresh();
    } finally {
      setLoading(false);
    }
  };

  const Field = ({
    label, name, type = "text", placeholder, required = false,
  }: {
    label: string; name: string; type?: string; placeholder?: string; required?: boolean;
  }) => (
    <div className="form-group">
      <label className="label">
        {label} {required && <span className="text-red-400">*</span>}
      </label>
      <input
        type={type}
        value={form[name as keyof typeof form]}
        onChange={(e) => set(name, e.target.value)}
        placeholder={placeholder}
        className="input-field"
        required={required}
      />
    </div>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label="Your Name" name="name" placeholder="John Doe" required />
        <Field label="Business / Dealership Name" name="business_name" placeholder="Coorg Auto Sales" required />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label="Phone Number" name="phone" type="tel" placeholder="+91 98765 43210" required />
        <Field label="WhatsApp Number" name="whatsapp" type="tel" placeholder="Same as phone or different" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* City */}
        <div className="form-group">
          <label className="label">City <span className="text-red-400">*</span></label>
          <div className="relative">
            <select
              value={form.city}
              onChange={(e) => set("city", e.target.value)}
              className="select-field pr-10"
              required
            >
              <option value="">Select City</option>
              {INDIAN_CITIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-300 pointer-events-none" />
          </div>
        </div>

        <Field label="Area / Location" name="location" placeholder="Madikeri, Virajpet..." required />
      </div>

      <Field label="Email Address" name="email" type="email" placeholder="you@example.com" required />

      <div className="form-group">
        <label className="label">Password <span className="text-red-400">*</span></label>
        <div className="relative">
          <input
            type={showPassword ? "text" : "password"}
            value={form.password}
            onChange={(e) => set("password", e.target.value)}
            placeholder="Min. 8 characters"
            className="input-field pr-11"
            required
            minLength={8}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-dark-400 hover:text-dark-200"
          >
            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <button type="submit" disabled={loading} className="btn-primary w-full py-3.5">
        {loading ? (
          <><Loader2 className="w-4 h-4 animate-spin" /> Creating account...</>
        ) : (
          "Create Dealer Account"
        )}
      </button>

      <p className="text-center text-dark-300 text-sm">
        Already have an account?{" "}
        <Link href="/auth/login" className="text-brand-400 hover:text-brand-300 font-medium transition-colors">
          Sign in
        </Link>
      </p>
    </form>
  );
}
