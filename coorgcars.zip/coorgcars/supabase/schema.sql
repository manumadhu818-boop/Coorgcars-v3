-- ============================================================
-- CoorgCars - Supabase Schema
-- Run this in your Supabase SQL editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- DEALERS TABLE
-- ============================================================
CREATE TABLE public.dealers (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  business_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  location TEXT NOT NULL,
  city TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  logo_url TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- CAR LISTINGS TABLE
-- ============================================================
CREATE TABLE public.car_listings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  dealer_id UUID NOT NULL REFERENCES public.dealers(id) ON DELETE CASCADE,
  
  -- Basic Info
  title TEXT NOT NULL,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  variant TEXT,
  year INTEGER NOT NULL,
  
  -- Specs
  fuel_type TEXT NOT NULL CHECK (fuel_type IN ('Petrol', 'Diesel', 'Electric', 'Hybrid', 'CNG', 'LPG')),
  transmission TEXT NOT NULL CHECK (transmission IN ('Manual', 'Automatic', 'AMT', 'CVT', 'DCT')),
  body_type TEXT CHECK (body_type IN ('Sedan', 'SUV', 'Hatchback', 'MUV', 'Coupe', 'Convertible', 'Pickup', 'Van')),
  color TEXT,
  
  -- Odometer & Ownership
  km_driven INTEGER NOT NULL,
  ownership INTEGER NOT NULL DEFAULT 1 CHECK (ownership BETWEEN 1 AND 5),
  
  -- Location
  city TEXT NOT NULL,
  location TEXT NOT NULL,
  
  -- Pricing
  price INTEGER NOT NULL,
  is_negotiable BOOLEAN DEFAULT TRUE,
  
  -- Description
  description TEXT,
  
  -- Images (array of Supabase storage URLs)
  images TEXT[] DEFAULT '{}',
  
  -- Meta
  is_active BOOLEAN DEFAULT TRUE,
  is_sold BOOLEAN DEFAULT FALSE,
  views INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_car_listings_dealer_id ON public.car_listings(dealer_id);
CREATE INDEX idx_car_listings_brand ON public.car_listings(brand);
CREATE INDEX idx_car_listings_city ON public.car_listings(city);
CREATE INDEX idx_car_listings_fuel_type ON public.car_listings(fuel_type);
CREATE INDEX idx_car_listings_price ON public.car_listings(price);
CREATE INDEX idx_car_listings_is_active ON public.car_listings(is_active);
CREATE INDEX idx_car_listings_created_at ON public.car_listings(created_at DESC);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

-- Dealers table RLS
ALTER TABLE public.dealers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view dealers"
  ON public.dealers FOR SELECT
  USING (true);

CREATE POLICY "Dealers can insert their own profile"
  ON public.dealers FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Dealers can update their own profile"
  ON public.dealers FOR UPDATE
  USING (auth.uid() = id);

-- Car listings RLS
ALTER TABLE public.car_listings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view active listings"
  ON public.car_listings FOR SELECT
  USING (is_active = true);

CREATE POLICY "Dealers can view their own listings"
  ON public.car_listings FOR SELECT
  USING (auth.uid() = dealer_id);

CREATE POLICY "Dealers can insert their own listings"
  ON public.car_listings FOR INSERT
  WITH CHECK (auth.uid() = dealer_id);

CREATE POLICY "Dealers can update their own listings"
  ON public.car_listings FOR UPDATE
  USING (auth.uid() = dealer_id);

CREATE POLICY "Dealers can delete their own listings"
  ON public.car_listings FOR DELETE
  USING (auth.uid() = dealer_id);

-- ============================================================
-- STORAGE BUCKET
-- ============================================================
-- Run this after creating the bucket named "car-images" in your Supabase dashboard

INSERT INTO storage.buckets (id, name, public)
VALUES ('car-images', 'car-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public can view car images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'car-images');

CREATE POLICY "Authenticated dealers can upload car images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'car-images' AND auth.role() = 'authenticated');

CREATE POLICY "Dealers can update their own images"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'car-images' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Dealers can delete their own images"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'car-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- ============================================================
-- FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER dealers_updated_at
  BEFORE UPDATE ON public.dealers
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

CREATE TRIGGER car_listings_updated_at
  BEFORE UPDATE ON public.car_listings
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

-- Increment view count function (bypasses RLS for view counting)
CREATE OR REPLACE FUNCTION public.increment_car_views(listing_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.car_listings
  SET views = views + 1
  WHERE id = listing_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
